import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";

export interface PublicProfile {
  full_name: string;
  title_en: string | null;
  title_fr: string | null;
  bio_en: string | null;
  bio_fr: string | null;
  email: string | null;
  phone: string | null;
  location: string | null;
  avatar_url: string | null;
  github_url: string | null;
  linkedin_url: string | null;
  twitter_url: string | null;
  calendar_url: string | null;
}

export const useProfile = () => {
  const [profile, setProfile] = useState<PublicProfile | null>(null);

  useEffect(() => {
    supabase.from("profile").select("*").limit(1).maybeSingle().then(({ data }) => {
      if (data) setProfile(data as any);
    });
  }, []);

  return profile;
};
